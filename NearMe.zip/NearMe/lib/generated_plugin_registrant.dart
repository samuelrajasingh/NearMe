//
// Generated file. Do not edit.
//

// ignore: unused_import
import 'dart:ui';

import 'package:location_web/location_web.dart';

import 'package:flutter_web_plugins/flutter_web_plugins.dart';

// ignore: public_member_api_docs
void registerPlugins(PluginRegistry registry) {
  LocationWebPlugin.registerWith(registry.registrarFor(LocationWebPlugin));
  registry.registerMessageHandler();
}
