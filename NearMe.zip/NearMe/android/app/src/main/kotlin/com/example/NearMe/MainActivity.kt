package com.example.NearMe

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
